public class Consumer implements Runnable {
 private SyncStack theStack;
 private int num;
 priva
 public Consumer (SyncStack s) {
theStack = s;
 num = counter++;
 }

public void run() {
 ch200; i++) {
 c = theStack.pop();
 System.out.println("Consumer" + num + ":" + c);

 try {
 Thre * 300));
 } catch (InterruptedException e) {
// ignore it
 }
 } 
}
}:" + c);

 try {
 Thre