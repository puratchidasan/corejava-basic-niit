package com.niit.btm.module9;

import java.io.File;

public class ReadCompleteDir {

	public static void readDir(File file) {

		if (file.isDirectory()) {
			String[] strings = file.list();
			for (String string : strings) {
				System.out.println(string);
			}

			File[] file2 = file.listFiles();
			for (File file3 : file2) {
				readDir(file3);
			}
		}
	}

	public static void main(String[] args) {

		File file = new File(
				"F:\\Dasan@NIIT\\AdvancedJAVAWorkspace\\CORE JAVA -BATCH 2");
		ReadCompleteDir.readDir(file);

	}

}
