package com.niit.btm.module1;

public class Greeting {
	public void greet() {
		System.out.println("Hello NIIT");
	}

	public void goodBye() {
		System.out.println("Bye From NIIT");
	}

	public String welcomeMessage() {
		return "Welcome To NIIT";
	}

	public int add(int a, int b) {
		return a + b;
	}
}