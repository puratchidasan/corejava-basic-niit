package com.niit.btm.module1;
//This class is simple java class to explain 
public class TestGreeting {

	public static void main(String[] hgfhf) {
		System.out.println("HelloWorld");
		Greeting g = new Greeting();
		g.greet();
		g.goodBye();
		System.out.println(g.welcomeMessage());
		System.out.println(g.add(25, 35));

	}
}