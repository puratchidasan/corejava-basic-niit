package com.niit.btm.module1;


public class CheckGreeting {

	public static void main(String[] args) {
		Greeting greeting = new Greeting();
		System.out.println(greeting.welcomeMessage());
	}

}
