package com.niit.btm.module4;

public class StringDemo {
	public static void main(String[] args) {
		String s = "NIIT";
		String s1 = " Students";
		int sound = 20;
		int sound1 = 30;
		System.out.println(s + s1);
		System.out.println(sound + s1 + sound1);
		System.out.println("----------------------------");
		int speed = 21;

		switch (speed) {
		case 20:
			System.out.println("Moving @ 20KPH");
			break;
		case 40:
			System.out.println("Moving @ 40KPH");
			break;
		case 60:
			System.out.println("Moving @ 60KPH");
			break;
		case 80:
			System.out.println("Moving @ 80KPH");
			break;
		case 100:
			System.out.println("Moving @ > 90KPH");
			break;
		default:
			System.out.println("Please Start Vehicle.");
			break;
		}
		System.out.println("----------------------------");
		long bigValue = 100;
		byte squash = (byte) bigValue;

		if (bigValue < 200) {
			System.out.println("IF");
		}
		System.out.println("IF");
		for (int i = 0; i < args.length; i++) {

		}
		// while (true) {
		// System.out.println("Hi");
		// }

	}

}
