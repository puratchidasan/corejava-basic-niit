package com.niit.btm.module4;

public class MyDate {
	private int day;
	private int month;
	private int year;

	public MyDate(MyDate date) {
		this.day = date.day;
		this.month = date.month;
		this.year = date.year;
	}

	public MyDate(int day, int month, int year) {
		this.day = day;
		this.month = month;
		this.year = year;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		this.day = day;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	@Override
	public String toString() {
		return "" + day + "-" + month + "-" + year;
	}

	public MyDate addDays(int moreDays) {
		MyDate newDate = new MyDate(this);
		newDate.day = newDate.day + moreDays;
		// Not Yet Implemented: wrap around code...
		return newDate;
	}
}
