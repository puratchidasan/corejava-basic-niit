package com.niit.btm.module7;

public class Philips implements MusicPlayer {

	public void play() {
		System.out.println("Playing");

	}

	public void next() {
		System.out.println("next");

	}

	public void previous() {
		System.out.println("previous");
	}

	public void stop() {
		System.out.println("stop");
	}

	public static void main(String[] args) {
		Philips philips = new Philips();
		philips.play();
		System.out.println(MusicPlayer.MAX_VOLUME);
	}
}
