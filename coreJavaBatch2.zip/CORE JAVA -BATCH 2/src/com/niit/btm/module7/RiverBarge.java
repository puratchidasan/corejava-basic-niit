package com.niit.btm.module7;

public class RiverBarge extends Vehicle {

	@Override
	public void calcFuelEff() {
		

	}

}
