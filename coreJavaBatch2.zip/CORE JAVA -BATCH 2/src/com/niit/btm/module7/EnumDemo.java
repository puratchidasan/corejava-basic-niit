package com.niit.btm.module7;

public class EnumDemo {
	
	public static void main(String[] args) {
		

	}

}
