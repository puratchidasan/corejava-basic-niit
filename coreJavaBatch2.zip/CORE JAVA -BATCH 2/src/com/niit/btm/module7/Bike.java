package com.niit.btm.module7;

public class Bike extends Vehicle {

	@Override
	void calcFuelEff() {
		// TODO Auto-generated method stub
		
	}

	

}
