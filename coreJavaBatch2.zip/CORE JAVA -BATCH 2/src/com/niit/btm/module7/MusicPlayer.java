package com.niit.btm.module7;

public interface MusicPlayer {

	int MAX_VOLUME = 100;

	void play();

	void next();

	void previous();

	void stop();

}
