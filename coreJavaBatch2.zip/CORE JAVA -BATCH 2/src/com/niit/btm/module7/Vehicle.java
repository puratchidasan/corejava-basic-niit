package com.niit.btm.module7;

public abstract class Vehicle {

	abstract void calcFuelEff();

	public void noOfWheels() {
	}
}
