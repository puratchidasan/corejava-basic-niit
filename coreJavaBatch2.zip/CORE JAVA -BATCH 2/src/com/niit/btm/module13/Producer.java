package com.niit.btm.module13;

public class Producer implements Runnable {
	private SyncStack theStack;
	private int num;
	private static int counter = 1;

	public Producer(SyncStack s) {
		theStack = s;
		num = counter++;
	}

	public void run() {
		char c;

		for (int i = 1; i <= 26; i++) {
			c = (char) (Math.random() * 26 + 'A');
			theStack.push(c);
			System.out.println( i +" Producer " + num + ": " + c);
			try {
				Thread.sleep((int) (Math.random() * 300));
			} catch (InterruptedException e) {
				// ignore it
			}
		}
	}
}
