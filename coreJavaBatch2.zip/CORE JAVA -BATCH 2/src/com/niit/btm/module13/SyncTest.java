package com.niit.btm.module13;

public class SyncTest {
	public static void main(String[] args) {

		SyncStack stack = new SyncStack();

		Producer producer = new Producer(stack);

		Thread thread = new Thread(producer);

		thread.start();

		Consumer consumer = new Consumer(stack);

		Thread thread2 = new Thread(consumer);

		thread2.start();

	}

}
