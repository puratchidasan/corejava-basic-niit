package com.niit.btm.module8;

public class NestedTryCatch {
	public static void main(String[] args) {
		int i = 10;
		int j = Integer.parseInt(args[0]);
		double k = 0;
		try {
			System.exit(0);
			k = i / j;
			System.out.println(k);
		} catch (ArithmeticException e) {
			e.printStackTrace();
		} catch (ArrayIndexOutOfBoundsException e) {
			e.printStackTrace();
		} finally {
			System.out.println("Always Runs.");
		}

	}

}
