package com.niit.btm.module8;

public class VariableDemo {
	static int i;

	public static void main(String[] args) {
		System.out.println(VariableDemo.i);
		System.out.println(false);
		System.out.println(10);
		System.out.println(10.908766);
		System.out.println("NIIT");
		

	}

}
