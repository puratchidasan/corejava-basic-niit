package com.niit.btm.module8;

import java.io.IOException;

public class SubClass extends SuperClass {
	public void play() throws IOException {

	}
}
