package com.niit.btm.module8;

import java.io.IOException;

public class SuperClass {

	public void play() throws IOException {
	}
}
