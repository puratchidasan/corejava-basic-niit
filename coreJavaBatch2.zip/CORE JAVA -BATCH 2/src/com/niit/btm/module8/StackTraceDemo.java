package com.niit.btm.module8;

public class StackTraceDemo {
	public void methodOne() {
		methodTwo();
	}

	public void methodTwo() {
		methodThree();
	}

	public void methodThree() {
		methodFour();
	}

	public void methodFour() {
		int i = 10;
		int j = 0;
		int k = 0;
		try {
			k = i / j;
			System.out.println(k);
		} catch (ArithmeticException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		StackTraceDemo demo = new StackTraceDemo();
		demo.methodOne();
	}

}
