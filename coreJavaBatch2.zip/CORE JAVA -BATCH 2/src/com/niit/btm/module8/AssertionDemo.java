package com.niit.btm.module8;

public class AssertionDemo {
	public static void main(String[] args) {
		int x = -8;
		if (x > 0) {
			System.out.println("X is greater than zero.");
		} else {
			System.out.println("Assertion Error.");
			assert (x == 0);			

		}

	}

}
