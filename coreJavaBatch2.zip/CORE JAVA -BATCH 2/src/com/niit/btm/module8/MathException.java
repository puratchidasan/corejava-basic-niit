package com.niit.btm.module8;

public class MathException extends Exception {
	public MathException() {
		super();
	}

	public MathException(String message) {
		super(message);
	}

}
