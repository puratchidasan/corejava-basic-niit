package com.niit.btm.module8;

public class ExceptionDemo {
	public static void main(String[] args) throws MathException {
		int i = 10;
		int j = 0;
		int k = 0;
		try {
			k = i / j;
			System.out.println(k);
		} catch (ArithmeticException e) {
			throw new MathException("Please provide valid value,Non Zero..");
		}

	}

}
