package com.niit.btm.module11;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MouseClickHandler extends MouseAdapter {

	public void mouseClicked(MouseEvent e) {

	}

}

