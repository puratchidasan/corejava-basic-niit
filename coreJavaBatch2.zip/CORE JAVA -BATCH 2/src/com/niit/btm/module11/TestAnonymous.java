package com.niit.btm.module11;

import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

public class TestAnonymous {

	private Frame f;
	private TextField tf;

	public TestAnonymous() {
		f = new Frame("Anonymous classes example");
		tf = new TextField(30);
	}

	public static void main(String args[]) {
		TestAnonymous obj = new TestAnonymous();
		obj.launchFrame();
	}

	public void launchFrame() {
		Label label = new Label("Click and drag the mouse");
		// Add components to the frame
		f.add(label, BorderLayout.NORTH);
		f.add(tf, BorderLayout.SOUTH);
		// Add a listener that uses an anonymous class
		f.addMouseMotionListener(new MouseMotionAdapter() {
			public void mouseDragged(MouseEvent e) {
				String s = "Mouse dragging: X = " + e.getX() + " Y = "
						+ e.getY();
				tf.setText(s);
			}
		});

		f.addMouseListener(new MouseClickHandler()); // Not shown
		// Size the frame and make it visible
		f.setSize(300, 200);
		f.setVisible(true);
	}

	public Frame getF() {
		return f;
	}

	public void setF(Frame f) {
		this.f = f;
	}

	public TextField getTf() {
		return tf;
	}

	public void setTf(TextField tf) {
		this.tf = tf;
	}

}
