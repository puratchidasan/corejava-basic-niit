package com.niit.btm.module11;

import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

public class TestInner {

	private Frame f;
	private TextField tf;

	public TestInner() {
		f = new Frame("Inner classes example");
		tf = new TextField(30);
	}

	class MyMouseMotionListener extends MouseMotionAdapter {
		public void mouseDragged(MouseEvent e) {
			String s = "Mouse dragging: X = " + e.getX() + " Y = " + e.getY();
			tf.setText(s);
		}
	}

	public void launchFrame() {
		Label label = new Label("Click and drag the mouse");
		// Add components to the frame
		f.add(label, BorderLayout.NORTH);
		f.add(tf, BorderLayout.SOUTH);
		// Add a listener that uses an Inner class
		f.addMouseMotionListener(new MyMouseMotionListener());
		f.addMouseListener(new MouseClickHandler());
		// Size the frame and make it visible
		f.setSize(300, 200);
		f.setVisible(true);
	}

	public static void main(String args[]) {
		TestInner obj = new TestInner();
		obj.launchFrame();
	}

	public Frame getF() {
		return f;
	}

	public void setF(Frame f) {
		this.f = f;
	}

	public TextField getTf() {
		return tf;
	}

	public void setTf(TextField tf) {
		this.tf = tf;
	}

}

