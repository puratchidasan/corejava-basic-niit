package com.niit.btm.module11;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ButtonHandler implements ActionListener {
	
	public void actionPerformed(ActionEvent e) {

		System.out.println("Action occurred");
		System.out.println("Button�s command is: " + e.getActionCommand());

	}

}
