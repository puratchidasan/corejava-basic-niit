package com.niit.btm.module9;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class ScannerDemo {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		String s = JOptionPane.showInputDialog("Test");
		System.out.println(s);
		int a = scanner.nextInt();
		int b = scanner.nextInt();
		
		String result =scanner.next();
		int total = a+b;
		System.out.println(result + " "+total);

		
		scanner.close();

	}

}
