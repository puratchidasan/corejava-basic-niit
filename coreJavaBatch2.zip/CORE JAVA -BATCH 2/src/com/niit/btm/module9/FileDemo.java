package com.niit.btm.module9;

import java.io.File;

public class FileDemo {
	public static void main(String[] args) {
		File file = new File(
				"F:\\Dasan@NIIT\\AdvancedJAVAWorkspace\\CORE JAVA -BATCH 2\\src");
		System.out.println(file.length());
		System.out.println("file.isDirectory():"+file.isDirectory());
		System.out.println("file.exists() : " + file.exists());
		System.out.println("file.canRead(): " + file.canRead());
		System.out.println("file.canWrite():" + file.canWrite());
		System.out.println("file.isHidden():" + file.isHidden());
		System.out.println("file.getName():" + file.getName());
		System.out.println("file.getPath():" + file.getPath());
		System.out.println(file.getAbsolutePath());
	}

}
