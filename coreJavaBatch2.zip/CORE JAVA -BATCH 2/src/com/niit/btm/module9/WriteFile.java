package com.niit.btm.module9;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class WriteFile {
	public static void main(String[] args) {
	File file = new File("NIIT.txt");
	InputStreamReader reader = new InputStreamReader(System.in);
	BufferedReader in = new BufferedReader(reader);
	try {
		PrintWriter writer = new PrintWriter(new FileWriter(file));
		String s = "";
		while ((s = in.readLine()) != null) {
			writer.println(s);
		}
		writer.close();
		in.close();
		reader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
