package com.niit.btm.module9;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class ListDemo {
	public static void main(String[] args) {
		List list =new Vector();
		list.add("1");
		list.add("3");
		list.add("3");
		list.add("4");
		list.add("5");
		list.add("7");
		list.add("8");
		list.add("90");
		
		System.out.println(list);
		System.out.println(list.size());

		
		// while (en.hasMoreElements()) {
		// type type = (type) en.nextElement();
		//			
		// }

	}

}
