package com.niit.btm.module9;

public class RuntimeArgs {

	public int add(int a, int b) {
		return a + b;
	}

	public static void main(String[] args) {

		for (String string : args) {
			System.out.println(string);
		}
		RuntimeArgs ra = new RuntimeArgs();
		int a = Integer.parseInt(args[0]);
		int b = Integer.parseInt(args[1]);
		System.out
				.println("The Addition of " + a + " and " + b + " : " + ra.add(a, b));

	}

}
