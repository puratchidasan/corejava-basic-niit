package com.niit.btm.module9;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReadFile {
	public static void main(String[] args) {
		File file = new File("Sunset.jpg");
		try {
			FileReader fileReader = new FileReader(file);
			BufferedReader reader = new BufferedReader(fileReader);
			String line ="";
			line = reader.readLine();
			while(line != null ){
				System.out.println(line);
				line = reader.readLine();
			}			
			reader.close();
			fileReader.close();			
		} catch (FileNotFoundException e) {
			System.out.println("File Not Found.");
		} catch (IOException e) {
			System.out.println("Not Able To Read");
		}

	}
}
