package com.niit.btm.module9;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

import com.niit.btm.module5.Dog;

public class SetDemo {
	public static void main(String[] args) {
		Set set = new TreeSet();
		 set.add("A");
		 set.add("T");
		 set.add("U");
		 set.add("H");
		 set.add(5.0D);
		 set.add(14353);
		set.add(new Dog());

		System.out.println(set);
		System.out.println(set.isEmpty());
		System.out.println(set.size());
		//System.out.println(set.contains("NIIT6"));
		//System.out.println(set.remove("NIIT"));
		System.out.println(set.size());

		Iterator<Dog> iterator = set.iterator();
		while (iterator.hasNext()) {
			Dog a = (Dog) iterator.next();
			System.out.println(a);
		}
		
		
	}

}
