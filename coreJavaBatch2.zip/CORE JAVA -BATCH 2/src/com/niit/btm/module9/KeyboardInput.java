package com.niit.btm.module9;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class KeyboardInput {
	public static void main(String args[]) {
		String s;
		// Create a buffered reader to read
		// each line from the keyboard.
		InputStreamReader ir = new InputStreamReader(System.in);
		BufferedReader in = new BufferedReader(ir);

		System.out.println("Unix: Type ctrl-d to exit."
				+ "\nWindows: Type ctrl-z to exit");
		try {
			// Read each input line and echo it to the screen.
			s = in.readLine();
			while (s != null) {
				System.out.println("Read: " + s);
				s = in.readLine();
				if("EXIT".equalsIgnoreCase(s)){
					System.exit(0);
				}
			}
			// Close the buffered reader.
			in.close();
		} catch (IOException e) { // Catch any IO exceptions.
			e.printStackTrace();
		}
	}
}
