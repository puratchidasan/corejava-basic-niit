package com.niit.btm.module9;

import java.util.Enumeration;
import java.util.Properties;

public class PropertiesDemo {
	public static void main(String[] args) {
		Properties properties = System.getProperties();
		Enumeration enumeration = properties.propertyNames();
		int increment = 0;
		while (enumeration.hasMoreElements()) {
			String key = (String) enumeration.nextElement();
			System.out.println("Key -" + increment + " :" + key + "="+properties.getProperty(key));
			increment++;
		}
		System.out.println(properties);
	}

}
