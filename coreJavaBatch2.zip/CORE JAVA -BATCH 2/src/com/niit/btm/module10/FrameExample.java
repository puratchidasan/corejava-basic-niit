package com.niit.btm.module10;

import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class FrameExample {

	private Frame f;

	public FrameExample() {
		f = new Frame("Hello Out There!");
	}

	public void launchFrame() {
		f.setSize(170, 170);
		f.setLocation(100,200);
		f.addWindowListener(new WindowAdapter(){
			@Override
			public void windowClosing(WindowEvent arg0) {
				System.out.println("About TO Close");
				
				System.exit(0);
			}
		});
		Color color =  new Color(83,208,99);
//		Font font =  new Font("Arial")
		f.setBackground(color);
		f.setVisible(true);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FrameExample guiWindow = new FrameExample();
		guiWindow.launchFrame();

	}
}
