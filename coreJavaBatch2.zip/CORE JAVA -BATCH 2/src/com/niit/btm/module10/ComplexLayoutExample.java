package com.niit.btm.module10;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Frame;
import java.awt.Panel;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JTextArea;

public class ComplexLayoutExample {
	private Frame f;
	private Panel p;
	private Button bw, bc;
	private JTextArea textArea;
	private Button bfile, bhelp;

	public ComplexLayoutExample() {
		f = new Frame("GUI example 3");
		bw = new Button("West");
		textArea = new JTextArea("Work space region");
		bfile = new Button("File");
		bhelp = new Button("Help");
	}

	public void launchFrame() {
		// Add bw and bc buttons in the frame border
		f.add(bw, BorderLayout.WEST);
		f.add(textArea, BorderLayout.CENTER);
		f.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent arg0) {
				System.out.println("About TO Close");

				System.exit(0);
			}
		});
		// Create panel for the buttons in the north border
		p = new Panel();
		p.add(bfile);
		p.add(bhelp);
		f.add(p, BorderLayout.NORTH);
		// Pack the frame and make it visible
		f.pack();
		f.setVisible(true);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ComplexLayoutExample gui = new ComplexLayoutExample();
		gui.launchFrame();
	}

}
