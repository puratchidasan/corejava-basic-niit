package com.niit.btm.module10;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Calculator implements ActionListener, FocusListener {

	JFrame frame = new JFrame("CLT Training");

	JButton addButton = null;
	JButton subButton = null;
	JButton mulButton = null;
	JButton divButton = null;

	JTextField firstNumber = null;
	JTextField secondNumber = null;

	public void launchFrame() {

		frame.setLayout(new FlowLayout());

		JLabel firstLabel = new JLabel("ENTER FIRST NUMBER");
		JLabel secondLabel = new JLabel("ENTER SECOND NUMBER");

		frame.setBackground(Color.yellow);

		firstNumber = new JTextField(10);
		secondNumber = new JTextField(10);

		firstNumber.setForeground(Color.blue);
		firstNumber.setBackground(Color.red);

		addButton = new JButton("ADD");
		subButton = new JButton("SUB");
		mulButton = new JButton("MUL");
		divButton = new JButton("DIV");

		frame.add(firstLabel);
		frame.add(firstNumber);
		frame.add(secondLabel);
		frame.add(secondNumber);

		addButton.addActionListener(this);
		subButton.addActionListener(this);
		mulButton.addActionListener(this);
		divButton.addActionListener(this);

		firstNumber.addFocusListener(this);

		frame.add(addButton);
		frame.add(subButton);
		frame.add(mulButton);
		frame.add(divButton);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(770, 100);
		frame.pack();
		frame.setResizable(false);
		frame.setLocation(0, 200);
		frame.setVisible(true);
	}

	// AWT system and Swing > JVM
	public static void main(String[] args) {
		new Calculator().launchFrame();

	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

		JButton button = (JButton) e.getSource();

		String aS = firstNumber.getText();
		String bS = secondNumber.getText();

		int a = Integer.parseInt(aS);
		int b = Integer.parseInt(bS);
		int c = 0;
		if (button == addButton) {
			System.out.println("Adding");
			c = a + b;
			JOptionPane.showMessageDialog(null, c);
		} else if (button == subButton) {
			System.out.println("sub");
			c = a - b;
			JOptionPane.showMessageDialog(null, c);
		} else if (button == mulButton) {
			System.out.println("Mul");
			c = a * b;
			JOptionPane.showMessageDialog(null, c);
		} else if (button == divButton) {
			System.out.println("div");
			c = a / b;
			JOptionPane.showMessageDialog(null, c);
		}

	}

	public void focusGained(FocusEvent arg0) {
		// TODO Auto-generated method stub
		System.out.println("Focus Gained");

	}

	public void focusLost(FocusEvent arg0) {
		JTextField button = (JTextField) arg0.getSource();
		if (button == firstNumber) {
			JOptionPane.showMessageDialog(null, "Thank you for entering...");
		}
	}

}
