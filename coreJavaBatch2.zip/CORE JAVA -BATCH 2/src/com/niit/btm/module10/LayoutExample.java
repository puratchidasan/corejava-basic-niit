package com.niit.btm.module10;

import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class LayoutExample {
	private Frame f;
	private Button b1;
	private Button b2;

	public LayoutExample() {
		f = new Frame("GUI example");
		b1 = new Button("Press Me");
		b2 = new Button("Don�t press Me Don�t press Me Don�t press Me");
	}

	public void launchFrame() {
		f.setLayout(new FlowLayout(FlowLayout.LEFT));
		f.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent arg0) {
				System.out.println("About TO Close");

				System.exit(0);
			}
		});
		f.add(b1);
		f.add(b2);
		f.add(b1);
		f.add(b2);
		f.add(b1);
		f.add(b2);
		f.pack();
		f.setVisible(true);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LayoutExample guiWindow = new LayoutExample();
		guiWindow.launchFrame();
	}
}
