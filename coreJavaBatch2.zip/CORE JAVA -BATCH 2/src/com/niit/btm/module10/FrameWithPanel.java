package com.niit.btm.module10;

import java.awt.Color;
import java.awt.Frame;
import java.awt.Panel;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class FrameWithPanel {
	private Frame f;
	private Panel pan;
	private Panel wPanel;

	public FrameWithPanel(String title) {
		f = new Frame(title);
		pan = new Panel();
		wPanel = new Panel();
	}

	public void launchFrame() {
		f.setSize(200, 200);
		f.setBackground(Color.blue);
		f.setLayout(null); // Use default layout
		f.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent arg0) {
				System.out.println("About TO Close");

				System.exit(0);
			}
		});
		
		pan.setBounds(0,0,850,200);
		wPanel.setBounds(0,200,850,200);
		//pan.setSize(850, 100);
		//wPanel.setSize(850, 400);
		
		pan.setBackground(Color.yellow);
		wPanel.setBackground(Color.white);
		f.add(pan);
		f.add(wPanel);
		f.setVisible(true);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FrameWithPanel guiWindow = new FrameWithPanel("Frame with Panel");
		guiWindow.launchFrame();
	}

}
