package com.niit.btm.module10;

import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class FlowExample {
	private Frame f;
	private Button button1;
	private Button button2;
	private Button button3;

	public FlowExample() {
		f = new Frame("Flow Layout");
		button1 = new Button("Ok");
		button2 = new Button("Open");
		button3 = new Button("Close");
	}

	public void launchFrame() {
		f.setLayout(new FlowLayout());
		f.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent arg0) {
				System.out.println("About TO Close");

				System.exit(0);
			}
		});
		f.add(button1);
		f.add(button2);
		f.add(button3);
		f.setSize(100, 100);
		f.setVisible(true);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FlowExample guiWindow = new FlowExample();
		guiWindow.launchFrame();
	}
}
