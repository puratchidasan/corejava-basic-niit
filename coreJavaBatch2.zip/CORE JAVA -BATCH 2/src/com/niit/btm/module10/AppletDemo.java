package com.niit.btm.module10;

import java.applet.Applet;
import java.awt.Graphics;

public class AppletDemo extends Applet {
	 
	@Override
	public void init() {
		System.out.println("In init");
	}
	@Override
	public void destroy() {
		System.out.println("In destroy");
	}
	@Override
	public void paint(Graphics g) {
		System.out.println("In paint");
		
		g.drawLine(100, 100, 300, 100);
		g.drawArc(300, 400, 100, 30, 20, 50);
		for(int i =0; i<100;i++){
			g.drawRect(10, 10, 100+i+2, 50 +i);
		}
		g.fillOval(300, 300, 200, 200);
		
	}
	@Override
	public void start() {
		System.out.println("In start");
	}
	@Override
	public void stop() {
		System.out.println("In stop");
	}

}
