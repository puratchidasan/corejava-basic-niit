package com.niit.btm.module10;

import java.awt.Button;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class GridExample {
	private Frame f;
	private Button b1, b2, b3, b4, b5, b6;

	public GridExample() {
		f = new Frame("Grid Example");
		b1 = new Button("1");
		b2 = new Button("2");
		b3 = new Button("3");
		b4 = new Button("4");
		b5 = new Button("5");
		b6 = new Button("6");
	}

	public void launchFrame() {
		f.setLayout(new GridLayout(3, 3));
		f.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent arg0) {
				System.out.println("About TO Close");

				System.exit(0);
			}
		});
		f.add(b1);
		f.add(b2);
		f.add(b3);
		f.add(b4);
		f.add(b5);
		f.add(b6);
		f.pack();
		f.setVisible(true);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GridExample grid = new GridExample();
		grid.launchFrame();
	}

}
