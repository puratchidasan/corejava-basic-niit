package com.niit.btm.module15;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class SimpleServer {
	public static void main(String[] args) {
		ServerSocket s = null;

		// Register your service on port 5432
		try {
			s = new ServerSocket(5432);
			System.out.println("Waiting For Request");
		} catch (IOException e) {
			e.printStackTrace();
		}
		// Run the listen/accept loop forever
		while (true) {
			try {
				// Wait here and listen for a connection
				Socket s1 = s.accept();
				System.out.println(s1.getInetAddress());
				System.out.println(s1.getLocalPort());
				System.out.print("Processing");
				// Get output stream associated with the socket
				OutputStream s1out = s1.getOutputStream();
				BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(
						s1out));

				// Send your string!
				bw.write("Hello Net World!\n");
				System.out.println(":- Processed.");
				bw.close();
				s1.close();
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
	}

}
