package com.niit.btm.module2;

import java.awt.Color;

/**
 * This class is used to create fan object which has property like wings,engine
 * and color with rotating speed function
 * 
 * @author Dasan
 * 
 */
public class Fan {

	private Color color = null;

	private Engine engine = null;

	private Wing wing = null;

	/**
	 * @return the color
	 */
	public Color getColor() {
		return color;
	}

	/**
	 * @param color
	 *            the color to set
	 */
	public void setColor(Color color) {
		this.color = color;
	}

	/**
	 * @return the engine
	 */
	public Engine getEngine() {
		return engine;
	}

	/**
	 * @param engine
	 *            the engine to set
	 */
	public void setEngine(Engine engine) {
		this.engine = engine;
	}

	/**
	 * @return the wing
	 */
	public Wing getWing() {
		return wing;
	}

	/**
	 * @param wing
	 *            the wing to set
	 */
	public void setWing(Wing wing) {
		this.wing = wing;
	}

	/**
	 * Gives Rotating speed of the fan.
	 * 
	 * @return speed of the Fan
	 */
	public int rotatingSpeed() {
		return 4;
	}

	/**
	 * Fan with color engine and wing
	 * 
	 * @param color
	 * @param engine
	 * @param wing
	 */
	public Fan(Color color, Engine engine, Wing wing) {
		this.color = color;
		this.engine = engine;
		this.wing = wing;
	}

	/**
	 * Fan with default state:
	 */
	public Fan() {
		super();
	}

}
