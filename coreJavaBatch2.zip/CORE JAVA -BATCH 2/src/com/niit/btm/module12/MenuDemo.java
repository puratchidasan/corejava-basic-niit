package com.niit.btm.module12;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.WindowConstants;

public class MenuDemo implements ActionListener {
	JFrame frame = null;
	JMenuBar menuBar = null;
	JButton button = null;
	JButton button1 = null;
	JMenu file = null;
	JMenu edit = null;
	JMenu source = null;
	JMenu help = null;

	JMenuItem open = null;
	JMenuItem newItem = null;
	JMenuItem close = null;
	JCheckBoxMenuItem checkBoxMenuItem = null;

	// JLabel label = null;

	public MenuDemo() {
		frame = new JFrame("SAMPLE Menu Demo");
		frame.setLayout(new FlowLayout());
		// label = new JLabel("THIS IS SAMPLE LABEL");
		button = new JButton("FIRE FIRST");
		button1 = new JButton("FIRE SECOND");
		button.setActionCommand("FIRST BUTTON");
		button1.setActionCommand("SECOND BUTTON");

		button.addActionListener(this);
		button1.addActionListener(this);
		menuBar = new JMenuBar();
		file = new JMenu("File");
		edit = new JMenu("Edit");
		source = new JMenu("Source");
		help = new JMenu("Help");

		open = new JMenuItem("Open");
		newItem = new JMenuItem("New");
		close = new JMenuItem("Close");
		checkBoxMenuItem = new JCheckBoxMenuItem("Work Offline", true);

		close.addActionListener(this);
		close.setActionCommand("CLOSE");
		file.add(open);
		file.add(newItem);
		file.addSeparator();
		file.add(checkBoxMenuItem);
		file.addSeparator();
		file.add(close);

		menuBar.add(file);
		menuBar.add(edit);
		menuBar.add(source);
		// menuBar.setHelpMenu(help);

		frame.setJMenuBar(menuBar);
		// frame.add(label,BorderLayout.SOUTH);
		// frame.add(button);
		// frame.add(button1);

		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		// frame.setResizable(false);
		Color color = new Color(199, 205, 235);
		frame.setBackground(color);
		frame.setForeground(Color.YELLOW);
		// label.setForeground(Color.magenta);
		//frame.pack();
		frame.setVisible(true);
		frame.setSize(800, 400);
	}

	public void launchFrame() {

	}

	public static void main(String[] args) {
		new MenuDemo();

	}

	public void actionPerformed(ActionEvent ae) {
		System.out.println(ae.getActionCommand());

		Object object = ae.getSource();

		if (object instanceof JButton) {
			JButton firedButton = (JButton) ae.getSource();
			if (firedButton == button) {
				System.out.println("Button");
			} else if (firedButton == button1) {
				System.out.println("Button1");
				// JOptionPane.showMessageDialog(null, label.getText());
			}
		} else {
			if (ae.getActionCommand().equals("CLOSE")) {
				System.exit(0);
			}
		}

	}

}
