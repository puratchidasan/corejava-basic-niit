package com.niit.btm.module12;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class SampleComponents implements FocusListener {
	JFrame frame = null;
	JButton button = null;
	JButton imageButton = null;
	Button awtButton = null;
	JPanel panel = null;
	JLabel label = null;
	JTextField field = null;
	JTextArea area = null;
	JCheckBox box = null;
	JRadioButton radioButton = null;
	JComboBox comboBox = null;
	JList list = null;

	public SampleComponents() {
		frame = new JFrame("SAMPLE COMPONENTS");
		button = new JButton("NIIT");
		awtButton = new Button("NIIT  AWT BUTTON");
		Icon icon = new ImageIcon("Sunset.jpg");
		imageButton = new JButton(icon);
		panel = new JPanel();
		label = new JLabel("USERNAME : ");
		field = new JTextField("Enter UserName", 15);
		field.addFocusListener(this);
		area = new JTextArea("Enter Address", 3, 8);
		box = new JCheckBox("JAVA");
		radioButton = new JRadioButton("MALE", true);
		Object[] array = new Object[5];
		array[0] = "JAVA";
		array[1] = "C++";
		array[2] = "C";
		array[3] = "C Sharp";
		array[4] = "PASCAL";
		comboBox = new JComboBox(array);
		list = new JList(array);

		button.setBackground(Color.GREEN);
		button.setForeground(Color.BLUE);
		// button.setEnabled(false);
		frame.add(panel, BorderLayout.WEST);
		// panel.add(button);
		// panel.add(awtButton);
		// panel.add(imageButton);
		// panel.add(label);
		panel.add(field);
		// panel.add(area);
		// panel.add(box);
		// panel.add(radioButton);
		// panel.add(comboBox);
		// panel.add(list);

		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		// frame.setResizable(false);
		// frame.setBackground(Color.YELLOW);
		frame.pack();
		frame.setVisible(true);
		frame.setSize(800, 400);
	}

	public void launchFrame() {

	}

	public static void main(String[] args) {
		SampleComponents components = new SampleComponents();

	}

	public void focusGained(FocusEvent e) {
		System.out.println("focusGained" + field.getText());

		

	}

	public void focusLost(FocusEvent e) {
		System.out.println("focusLost" + field.getText());
	}

}
