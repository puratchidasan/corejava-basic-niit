package com.niit.btm.module14;

import java.io.*;

public class TestNodeStreams {
	public static void main(String[] args) {
		try {
			FileReader input = new FileReader("Consumer.java");
			FileWriter output = new FileWriter("CopyOfConsumer.java");
			char[] abc = new char[128];
			int charsRead;

			// read the first buffer
			charsRead = input.read(abc);
			System.out.println("REad : "+charsRead);
			while (charsRead != -1) {
				// write the buffer out to the output file
				output.write(abc, 0, 100);

				// read the next buffer
				charsRead = input.read(abc);
			}

			input.close();
			output.flush();
			output.close();
			System.out.println("It's Done.");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}