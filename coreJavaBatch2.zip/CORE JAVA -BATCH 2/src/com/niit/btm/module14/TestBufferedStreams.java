package com.niit.btm.module14;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class TestBufferedStreams {

	public static void main(String[] args) {
		try {
			FileReader fileReader = new FileReader("Consumer.java");
			BufferedReader bufferedReader = new BufferedReader(fileReader);

			FileWriter fileWriter = new FileWriter("bufferDemo.java");
			BufferedWriter writer = new BufferedWriter(fileWriter);

			String str = bufferedReader.readLine();

			while (str != null) {
				writer.write(str, 0, str.length());
				writer.newLine();
				str = bufferedReader.readLine();
			}
			bufferedReader.close();
			fileReader.close();
			writer.flush();
			writer.close();
			fileWriter.close();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
