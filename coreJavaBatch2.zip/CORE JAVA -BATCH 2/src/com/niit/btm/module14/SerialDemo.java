package com.niit.btm.module14;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import com.niit.btm.module5.Dog;

public class SerialDemo {

	public static void main(String[] args) {

		Dog dog = new Dog();
		dog.setDogColor("WHITE");
		FileOutputStream fileOutputStream;
		try {
			fileOutputStream = new FileOutputStream("Sample.txt");
			DataOutputStream outputStream = new DataOutputStream(
					fileOutputStream);
			ObjectOutputStream stream = new ObjectOutputStream(outputStream);
			stream.writeObject(dog);
			System.out.println("It's Done");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
