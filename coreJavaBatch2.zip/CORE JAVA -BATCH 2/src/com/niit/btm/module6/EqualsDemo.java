package com.niit.btm.module6;

public class EqualsDemo {

	public static void main(String[] args) {
		String s = "NIIT";
		String s1 = "niit";
		if (s.equalsIgnoreCase(s1)) {
			System.out.println("s and s1 equal.");
		}else{
			System.out.println("Content not Same");
		}

		if (s == s1) {
			System.out.println("s==s1");
		}else{
			System.out.println("not Same");
		}
	}
}
