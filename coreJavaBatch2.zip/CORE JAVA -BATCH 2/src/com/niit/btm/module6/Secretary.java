package com.niit.btm.module6;

public class Secretary extends Employee {

}
