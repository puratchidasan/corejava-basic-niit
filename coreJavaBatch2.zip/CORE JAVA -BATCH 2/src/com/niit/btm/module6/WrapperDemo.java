package com.niit.btm.module6;

public class WrapperDemo {

	public static void main(String[] args) {
		String s = "niit";
		int i = Integer.parseInt(s);
		System.out.println(i);
		int j =100;
		Integer integer = j;
		int k = integer.intValue();
		
		
	}

}
