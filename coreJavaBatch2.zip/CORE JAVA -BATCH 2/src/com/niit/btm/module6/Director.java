package com.niit.btm.module6;

public class Director extends Manager {
	private double carAllowance=100;

	/**
	 * @return the carAllowance
	 */
	public double getCarAllowance() {
		return carAllowance;
	}

	/**
	 * @param carAllowance
	 *            the carAllowance to set
	 */
	public void setCarAllowance(double carAllowance) {
		this.carAllowance = carAllowance;
	}

	public void increaseAllowance() {

	}
}
