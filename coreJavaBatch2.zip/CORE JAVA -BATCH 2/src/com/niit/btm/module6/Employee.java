package com.niit.btm.module6;

import java.util.Date;

public class Employee {

	private static final double BASE_SALARY = 15000.00;
	private String name = "KUMAR";
	private double salary = 1000.0;
	private Date birthDate = null;

	public Employee() {
		super();

	}

	public Employee(String name, double salary) {
		this(name, BASE_SALARY, null);
	}

	public Employee(String name, double salary, Date birthDate) {

	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the salary
	 */
	public double getSalary() {
		return salary;
	}

	/**
	 * @param salary
	 *            the salary to set
	 */
	public void setSalary(double salary) {
		this.salary = salary;
	}

	/**
	 * @return the birthDate
	 */
	public Date getBirthDate() {
		return birthDate;
	}

	/**
	 * @param birthDate
	 *            the birthDate to set
	 */
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	public String getDetails() {
		return "Employee Name :" + name + " and his Salary :Rs." + salary;
	}

	@Override
	public String toString() {
		return "Employee Name :" + name + " and his Salary :Rs." + salary;
	}
}
