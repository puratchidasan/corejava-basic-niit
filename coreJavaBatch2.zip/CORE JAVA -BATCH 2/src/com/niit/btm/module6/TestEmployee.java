package com.niit.btm.module6;

public class TestEmployee {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		Employee employee = new Employee();
		System.out.println(employee);
		
		
		// Employee employee = new Employee("RAM", 20000);
		// System.out.println("Name : " + employee.getName());
		// System.out.println("Salary : " + employee.getSalary());
		// System.out
		// .println("Details of the Employee : " + employee.getDetails());
		// System.out.println("-------------");
		// Employee employee2 = new Manager();
		// System.out.println("Details of the Employee : "
		// + employee2.getDetails());

		// Employee emp = new Employee();
		// Employee emp1 = new Manager();
		// Employee emp2 = new Secretary();
		// Employee emp3 = new Engineer();
		// Employee emp4 = new Director();
		// TestEmployee testEmployee = new TestEmployee();
		// testEmployee.findEmployee(emp4);

	}

	public void findEmployee(Employee emp) {

		// System.out.println(emp.getDetails());

		if (emp instanceof Manager) {
			Manager manager = (Manager) emp;
			Director director = (Director) manager;
			System.out.println(director.getCarAllowance());
			System.out.println(manager.getDetails());
		} else if (emp instanceof Engineer) {
			Engineer engineer = (Engineer) emp;
			System.out.println(engineer.getDetails());
		} else if (emp instanceof Secretary) {
			Secretary secretary = (Secretary) emp;
			System.out.println(secretary.getDetails());
		} else if (emp instanceof Director) {
			Director director = (Director) emp;
			System.out.println(director.getCarAllowance());

		}

	}

}
