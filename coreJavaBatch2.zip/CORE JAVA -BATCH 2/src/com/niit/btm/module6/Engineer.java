package com.niit.btm.module6;

public class Engineer extends Employee {

}
