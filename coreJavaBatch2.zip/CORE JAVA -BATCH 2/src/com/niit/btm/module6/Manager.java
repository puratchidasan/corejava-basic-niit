package com.niit.btm.module6;

public class Manager extends Employee {
	
	private String department = "SOFTWARE";

	/**
	 * @return the department
	 */
	public String getDepartment() {
		return department;
	}

	/**
	 * @param department
	 *            the department to set
	 */
	public void setDepartment(String department) {
		this.department = department;
	}

	public String getDetails() {

		return "Employee Name :" + getName() + " and his Salary :Rs."
				+ getSalary() + " his department : " + department;
	}

}
