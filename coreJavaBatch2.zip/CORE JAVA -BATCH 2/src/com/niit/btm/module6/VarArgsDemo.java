package com.niit.btm.module6;

public class VarArgsDemo {

	public static int findSum(int... i) {
		int k = 0;
		for (int j : i) {
			k += j;
		}
		return k;
	}

	public static void main(String[] args) {
			System.out.println(VarArgsDemo.findSum(1, 2, 3, 4, 5, 5,232,344,444,555,666));
	}

}
