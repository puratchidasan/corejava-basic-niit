package com.niit.btm.module5;


public class ArrayDemo {
	public static void main(String[] args) {

		int[] intArray = new int[5];

		for (int i = 0; i < intArray.length; i++) {
			intArray[i] = 10 + i;
			System.out.println("The Values : " + intArray[i]);
		}
		System.out.println("---------------------------------------");
		// Enhanced For Loop : JDK 1.5
		for (int i : intArray) {
			System.out.println("The Values : " + i);
		}
		System.out.println("---------------------------------------");
		Dog[] dogs = new Dog[3];
		dogs[0] = new Dog("Black", 25);
		dogs[1] = new Dog("Brown", 35);

		for (Dog dog : dogs) {
			System.out.println("The Dog Value : " + dog);
			// System.out.println("The Dog Weight : " + dog.getDogWeight()
			// + " The Dog Color : " + dog.getDogColor());
		}

		int[] myArray = { 1, 2, 3, 4, 5, 6 };

		int[] hold = { 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 };

		System.arraycopy(myArray, 0, hold, 1, myArray.length);

		for (int i : hold) {
			System.out.println(i);
		}

		int[] array = new int[2];
		array[0] = 5;
		array[1] = 6;

		int[] copyArray = new int[0];
		copyArray = array;
		System.out.println("-------------------------------");
		for (int i : copyArray) {
			System.out.println(i);
		}
	}

}
