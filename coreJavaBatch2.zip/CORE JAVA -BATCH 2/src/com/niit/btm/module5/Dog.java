package com.niit.btm.module5;

import java.io.Serializable;

public class Dog implements Serializable {

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((dogColor == null) ? 0 : dogColor.hashCode());
		long temp;
		temp = Double.doubleToLongBits(dogWeight);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Dog other = (Dog) obj;
		if (dogColor == null) {
			if (other.dogColor != null)
				return false;
		} else if (!dogColor.equals(other.dogColor))
			return false;
		if (Double.doubleToLongBits(dogWeight) != Double
				.doubleToLongBits(other.dogWeight))
			return false;
		return true;
	}

	private String dogColor;
	private double dogWeight = 0.0;

	/**
	 * @return the dogColor
	 */
	public String getDogColor() {
		return dogColor;
	}

	/**
	 * @param dogColor
	 *            the dogColor to set
	 */
	public void setDogColor(String dogColor) {
		this.dogColor = dogColor;
	}

	/**
	 * @return the dogWeight
	 */
	public double getDogWeight() {
		return dogWeight;
	}

	/**
	 * @param dogWeight
	 *            the dogWeight to set
	 */
	public void setDogWeight(double dogWeight) {
		this.dogWeight = dogWeight;
	}

	public Dog(String dogColor, double dogWeight) {
		this.dogColor = dogColor;
		this.dogWeight = dogWeight;
	}

	public Dog() {
		super();
		System.out.println("Default Constructor.");
	}

	@Override
	public String toString() {
		return "Color : " + dogColor + " dogWeight : " + dogWeight;
	}

}
